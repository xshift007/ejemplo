const NotFound = () => {
    return (
        <div>
            <p>Página web aún no esta disponible...</p>
        </div>
    );
}
 
export default NotFound;